"use strict";

// Q5: Hoisting Lab
// Original behavior explained:
// console.log(score) prints undefined because var is hoisted and initialized to undefined.
// announce() works because function declarations are hoisted with their function body.
// Calling startGame() before status initialization would throw ReferenceError because let is in the temporal dead zone.

var score = 50;
let status = "ready";
function announce() {
  console.log("Game started");
}
function startGame() {
  console.log(status);
}
console.log("Fixed sequence:");
console.log(score);
announce();
startGame();

// Arrow functions are expressions assigned to variables; they are not callable before initialization.
const announceArrow = () => console.log("Game started (arrow)");
const startGameArrow = () => console.log(status);
console.log("Arrow-function version:");
announceArrow();
startGameArrow();

// To observe the original trap safely, uncomment these lines one at a time:
// console.log(score); announce(); var score = 50;
// startGame(); let status = "ready"; // would throw ReferenceError if startGame reads status before initialization.
