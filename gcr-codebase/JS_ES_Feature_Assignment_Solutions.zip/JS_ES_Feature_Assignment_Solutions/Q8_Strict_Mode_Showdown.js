"use strict";

// Q8: Strict Mode Showdown
// These invalid snippets are executed in isolated functions so the main file can continue.
try {
  Function('"use strict"; return (function(a, a) { return a; });')();
} catch (error) {
  console.log(`Strict duplicate parameters: ${error.name} - ${error.message}`);
}
try {
  Function('"use strict"; total = 10;')();
} catch (error) {
  console.log(`Strict undeclared assignment: ${error.name} - ${error.message}`);
}
try {
  Function('"use strict"; var total = 10; delete total;')();
} catch (error) {
  console.log(`Strict delete variable: ${error.name} - ${error.message}`);
}

// Without strict mode, duplicate parameter names and assigning an undeclared global
// may be accepted (depending on environment); deleting a declared variable still returns false.
// Correct ES6 version:
function demo(a, b) {
  const total = 10;
  console.log(`Correct demo: a=${a}, b=${b}, total=${total}`);
}
demo(5, 10);
