 "use strict";

// Q10: Nested Hoisting and Closures
function outer() {
  console.log("outer count before declaration:", count); // undefined: outer's var is hoisted
  var count = 5;

  function inner() {
    console.log("inner count before declaration:", count); // undefined: inner has its own hoisted var count
    var count = 10;
    console.log("inner count after declaration:", count); // 10
  }
  inner();
  console.log("outer count after inner:", count); // 5; inner's local count is separate
}
outer();

// Arrow version: arrow functions do not create their own `this` or `arguments`,
// but a local `var count` inside the arrow still creates its own function scope.
function outerArrowDemo() {
  var count = 5;
  const inner = () => {
    console.log("arrow inner sees outer count:", count); // no local shadowing here
  };
  inner();
}
outerArrowDemo();

// Debug tip: step into inner and inspect the separate Local scopes and Call Stack.
