"use strict";

// Q1: Dynamic Data Parser
const apiData = ["25", "true", "false", "NaN", "                     ", "100px", "3.14", null, undefined];
const validNumbers = [];
const invalidNumbers = [];

console.log("=== Dynamic Data Parser Report ===");
for (let i = 0; i < apiData.length; i++) {
  const value = apiData[i];
  const numberValue = Number(value);
  const booleanValue = Boolean(value);
  const stringValue = String(value);
  const isBlankString = typeof value === "string" && value.trim() === "";
  const isInvalid = Number.isNaN(numberValue) || isBlankString ||
    (typeof value === "string" && value.trim() === "100px");

  console.log(`Item ${i + 1}: original=${stringValue}, Number=${numberValue}, Boolean=${booleanValue}, String="${stringValue}"`);

  if (isInvalid) {
    invalidNumbers.push({ index: i, value, reason: Number.isNaN(numberValue) ? "Number conversion produced NaN" : "Blank or unsupported numeric text" });
    console.log(`  INVALID: ${String(value)}`);
  } else {
    validNumbers.push(numberValue);
    console.log(`  VALID NUMBER: ${numberValue}`);
  }
}
console.log("Valid numeric data:", validNumbers);
console.log("Invalid data:", invalidNumbers);
console.log(`Totals: ${validNumbers.length} valid, ${invalidNumbers.length} invalid`);
