"use strict";

// Q9: JSON Audit
const rawData = [
  '{"user":"Alex","age":25}',
  '{"id":2}',
  '{invalid}',
  '{"user":"Mina","age":"22"}'
];
const cleanData = [];
const errors = [];
const adults = [];

rawData.forEach((raw, index) => {
  const lineNumber = index + 1;
  try {
    const parsed = JSON.parse(raw);
    if (!Object.prototype.hasOwnProperty.call(parsed, "user") ||
        !Object.prototype.hasOwnProperty.call(parsed, "age")) {
      throw new Error("Missing required key: user or age");
    }
    const age = Number(parsed.age);
    if (!Number.isFinite(age)) throw new TypeError("Age is not a valid number");
    const record = { ...parsed, age };
    cleanData.push(record);
    if (age >= 18) adults.push(record);
    console.log(`Line ${lineNumber}: valid JSON record`, record);
  } catch (error) {
    errors.push({ lineNumber, message: error.message, raw });
    console.log(`Line ${lineNumber}: ERROR - ${error.message}`);
  }
});
console.log("Clean data:", cleanData);
console.log("Errors:", errors);
console.log("Users under 18:", cleanData.filter((user) => user.age < 18));
console.log("Adult users:", adults);

// Debug tip: break at JSON.parse and inspect lineNumber, raw, and the exception path.
