"use strict";

// Q6: Pyramid Pattern Generator
// Run with Node.js. Enter a positive row count, or press Enter to use default 5.
const readline = require("node:readline");
const rl = readline.createInterface({ input: process.stdin, output: process.stdout });

rl.question("Number of pyramid rows (default 5): ", (answer) => {
  const parsed = Number(answer);
  const rows = answer.trim() === "" ? 5 : parsed;
  if (!Number.isInteger(rows) || rows < 1 || rows > 50) {
    console.log("Please enter a whole number from 1 to 50.");
  } else {
    console.log("=== Pyramid ===");
    for (let i = 1; i <= rows; i++) {
      let line = "";
      for (let j = 1; j <= i; j++) line += "* ";
      console.log(line.trimEnd());
    }
  }
  rl.close();
});

// Debug tip: watch i, j, and line. Replacing let with var changes block scope;
// var reuses one function-scoped binding, which can cause surprises in callbacks.
