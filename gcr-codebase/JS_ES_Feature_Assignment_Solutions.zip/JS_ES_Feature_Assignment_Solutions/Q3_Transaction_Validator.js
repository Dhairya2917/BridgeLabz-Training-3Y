"use strict";

// Q3: Transaction Validator
const transactions = [
  { id: 1, amount: 2000 },
  { id: 2, amount: -500 },
  { id: 3 },
  null
];
const validTransactions = [];
const invalidTransactions = [];

transactions.forEach((transaction, index) => {
  try {
    if (transaction === null) throw new TypeError("Null transaction entry");
    if (transaction.id === undefined || transaction.amount === undefined) {
      throw new ReferenceError("Missing transaction id or amount");
    }
    if (transaction.amount < 0) throw new RangeError("Negative transaction amount");
    validTransactions.push(transaction);
    console.log(`Transaction ${index + 1}: VALID`, transaction);
  } catch (error) {
    invalidTransactions.push({ index: index + 1, transaction, category: error.name, message: error.message });
    console.log(`Transaction ${index + 1}: INVALID [${error.name}] ${error.message}`);
  }
});
console.log("Valid transactions:", validTransactions);
console.log("Invalid transactions:", invalidTransactions);
console.log(`Summary: ${validTransactions.length} successful, ${invalidTransactions.length} failed`);

// Debug tip: set a breakpoint inside forEach and watch transaction, index, validTransactions, invalidTransactions.
