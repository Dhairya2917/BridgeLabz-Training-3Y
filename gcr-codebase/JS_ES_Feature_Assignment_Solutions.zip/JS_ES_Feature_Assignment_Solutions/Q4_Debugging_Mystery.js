"use strict";

// Q4: The undeclared assignment throws ReferenceError in strict mode.
function showBrokenMessage() {
  try {
    greeting = "Welcome"; // Error: greeting was never declared.
    console.log(greeting);
  } catch (error) {
    console.log(`Expected error: ${error.name} - ${error.message}`);
  }
}
showBrokenMessage();

// Fixed version: declare the variable in the function's local scope.
function showMessage() {
  const greeting = "Welcome";
  console.log(greeting);
}
showMessage();

// Debug tip: add greeting to Watch; step into showMessage and inspect the call stack.
